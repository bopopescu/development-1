//
//  UYLScaledTextStyleViewController.h
//  DynamicText
//
//  Created by Keith Harrison on 18/12/2013.
//  Copyright (c) 2013 Keith Harrison. All rights reserved.
//

#import "UYLTextStyleViewController.h"

@interface UYLScaledTextStyleViewController : UYLTextStyleViewController

@end
