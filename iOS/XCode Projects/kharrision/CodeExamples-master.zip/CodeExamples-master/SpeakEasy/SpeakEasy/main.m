//
//  main.m
//  SpeakEasy
//
//  Created by Keith Harrison on 04/01/2014.
//  Copyright (c) 2014 Keith Harrison. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UYLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UYLAppDelegate class]));
    }
}
