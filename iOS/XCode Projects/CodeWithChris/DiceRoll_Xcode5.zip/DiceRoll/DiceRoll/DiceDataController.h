//
//  DiceDataController.h
//  DiceRoll
//
//  Created by Christopher Ching on 2013-09-19.
//  Copyright (c) 2013 CodeWithChris. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DiceDataController : NSObject

- (int)getDieNumber;

@end
