# Objective-C Login System

An easy way to show a login screen before showing the real content (like the Facebook system).
