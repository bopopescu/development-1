//
//  MainView.h
//  LoginExample
//
//  Created by Frederik Jacques on 13/03/13.
//  Copyright (c) 2013 thenerd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIView

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UIButton *btnLogout;

@end
