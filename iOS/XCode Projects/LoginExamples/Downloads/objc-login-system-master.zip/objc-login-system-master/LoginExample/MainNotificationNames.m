//
//  MainNotificationNames.m
//  LoginExample
//
//  Created by Frederik Jacques on 14/03/13.
//  Copyright (c) 2013 thenerd. All rights reserved.
//

#import "MainNotificationNames.h"

@implementation MainNotificationNames

@end
