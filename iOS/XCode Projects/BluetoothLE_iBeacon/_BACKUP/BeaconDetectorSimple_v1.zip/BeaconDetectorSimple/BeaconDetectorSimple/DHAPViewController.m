//
//  DHAPViewController.m
//  BeaconDetectorSimple
//
//  Created by Brian Sterner on 6/3/14.
//  Copyright (c) 2014 DHAP Digital Inc. All rights reserved.
//

#import "DHAPViewController.h"
#import "RWTItem.h"

NSString * const kRWTStoredItemsKey = @"storedUuids";

@interface DHAPViewController ()
@property (strong, nonatomic) NSMutableArray *items;
@end

@implementation DHAPViewController

- (IBAction)fetchGreeting;
{
    NSURL *url = [NSURL URLWithString:@"http://rest-service.guides.spring.io/greeting"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:^(NSURLResponse *response,
                                               NSData *data, NSError *connectionError)
     {
         if (data.length > 0 && connectionError == nil)
         {
             NSDictionary *greeting = [NSJSONSerialization JSONObjectWithData:data
                                                                      options:0
                                                                        error:NULL];
             self.greetingId.text = [[greeting objectForKey:@"id"] stringValue];
             self.greetingContent.text = [greeting objectForKey:@"content"];
         }
     }];
}

-(void)locationManager:(CLLocationManager*)manager
       didRangeBeacons:(NSArray*)beacons
              inRegion:(CLBeaconRegion*)region
{
    NSLog(@"Beacon found!!!");

    // Beacon found!
    self.statusLabel.text = @"Beacon found!";
    self.dynamicLabel.text = @"GOOD WORK NOW TRY TO GET THE UUID INFO";
    //self.uuidLabel.text = @"The correct beacon technical info should be displayed here";
    
    // This should provide reference in the beacons that we're found
    CLBeacon *foundBeacon = [beacons firstObject];
    NSString *firstBeaconUuidLabel = [NSString stringWithFormat:@"%@", foundBeacon.proximityUUID.UUIDString];
    //self.uuidLabel.text = firstBeaconUuidLabel;
    
    NSInteger count = [beacons count];
    NSString *countLabel = [NSString stringWithFormat:@"%ld", (long)count];
    self.beaconCount.text = countLabel;
    
    // Clear beacon display area
    NSMutableString *beaconInfo = [NSMutableString string];
    [beaconInfo setString:@""];
    self.dynamicLabel.text = beaconInfo;
    
    // Now try to cycle through the list of beacons and print out their information
    
    // Clear message if beacons found
    if (count > 0) {
        [beaconInfo setString:@""];
    }

    for (CLBeacon *beacon in beacons) {
        CLProximity proximity = beacon.proximity;
        NSString *proximityValue = [self nameForProximity:proximity];
        NSString *displayUuid = beacon.proximityUUID.UUIDString;
        NSString *displayMajor = [NSString stringWithFormat:@"%@", beacon.major];
        NSString *displayMinor = [NSString stringWithFormat:@"%@", beacon.minor];
        NSString *displayLine = [NSString stringWithFormat:@"Beacon UUID: %@\nBeacon Major: %@\nBeacon: Minor: %@\nBeacon: Proximity: %@\n\n", displayUuid, displayMajor, displayMinor, proximityValue];
        [beaconInfo appendString:displayLine];
        NSLog(@"%@", displayLine);

        for (RWTItem *item in self.items) {
            if ([item isEqualToCLBeacon:beacon]) {
                NSLog(@"Found matching beacon with major:minor values [%@:%@]", displayMajor, displayMinor);
                item.lastSeenBeacon = beacon;
            } else {
                NSLog(@"Adding beacon with major:minor values [%@:%@]", displayMajor, displayMinor);
            }
        }
    }

    /*
    for (int i = 0; i < count; i++) {
        beacon = [beacons objectAtIndex:i];
        CLProximity proximity = beacon.proximity;
        NSString *proximityValue = [self nameForProximity:proximity];
        NSString *displayUuid = beacon.proximityUUID.UUIDString;
        NSString *displayMajor = [NSString stringWithFormat:@"%@", beacon.major];
        NSString *displayMinor = [NSString stringWithFormat:@"%@", beacon.minor];
        [beaconInfo appendString:[NSString stringWithFormat:@"Beacon UUID: %@\r\nBeacon Major: %@\r\nBeacon: Minor: %@\r\nBeacon: Proximity: %@:\r\n\r\n", displayUuid, displayMajor, displayMinor, proximityValue]];
        
        RWTItem *newItem = [[RWTItem alloc] initWithName:displayUuid
                                                    uuid:beacon.proximityUUID
                                                   major:[displayMajor intValue]
                                                   minor:[displayMinor intValue]];
        if ([newItem isEqualToCLBeacon:beacon]) {
            newItem.lastSeenBeacon = beacon;
            NSLog(@"Newly created beacon is equal to CLBeacon");
        }
        
    }
    */
    self.dynamicLabel.text = beaconInfo;
}

- (NSString *)nameForProximity:(CLProximity)proximity {
    switch (proximity) {
        case CLProximityUnknown:
            return @"Unknown";
            break;
        case CLProximityImmediate:
            return @"Immediate";
            break;
        case CLProximityNear:
            return @"Near";
            break;
        case CLProximityFar:
            return @"Far";
            break;
    }
}

- (void)locationManager:(CLLocationManager*)manager didEnterRegion:(CLRegion *)region
{
    NSLog(@"Beacon entered region!!");
    
    // We entered a region, now start looking for our target beacons!
    self.statusLabel.text = @"Finding beacons.";
    [self.locationManager startRangingBeaconsInRegion:self.myBeaconRegion];
}

-(void)locationManager:(CLLocationManager*)manager didExitRegion:(CLRegion *)region
{
    // Exited the region
    NSLog(@"Beacon EXITED region!!");
    self.statusLabel.text = @"None found.";
    [self.locationManager stopRangingBeaconsInRegion:self.myBeaconRegion];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"Application started");
    
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    
    // Create a NSUUID with the same UUID as the broadcasting beacon
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"B9407F30-F5F8-466E-AFF9-25556B57FE6D"];
    self.myBeaconRegion = [[CLBeaconRegion alloc] initWithProximityUUID:uuid
                                                             identifier:@"Estimote Region"];
    // only notify user if app display is on
    //self.myBeaconRegion.notifyEntryStateOnDisplay = YES;
    //self.myBeaconRegion.notifyOnEntry = NO;
    //self.myBeaconRegion.notifyOnExit = NO;
    
    // Tell location manager to start monitoring for the beacon region
    [self.locationManager startMonitoringForRegion:self.myBeaconRegion];
    
    // NOTE: There is a startRangingBeaconsInRegion method which will report events on a specific beacon region with regards to movement (range changes)
    
    // Check if beacon monitoring is available for this device
    if (![CLLocationManager isMonitoringAvailableForClass:[CLBeaconRegion class]]) {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Monitoring not available" message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil]; [alert show]; return;
    }
    
    NSLog(@"viewDidLoaded completed");
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
