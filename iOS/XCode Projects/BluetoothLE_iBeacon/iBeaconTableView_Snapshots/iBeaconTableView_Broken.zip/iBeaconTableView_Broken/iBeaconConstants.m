//
//  iBeaconConstants.m
//  TableViewStory
//
//  Created by Brian Sterner on 6/10/14.
//  Copyright (c) 2014 DHAP Digital Inc. All rights reserved.
//

#include "iBeaconConstants.h"

NSString * const ESTIMOTE_UUID = @"B9407F30-F5F8-466E-AFF9-25556B57FE6D";
