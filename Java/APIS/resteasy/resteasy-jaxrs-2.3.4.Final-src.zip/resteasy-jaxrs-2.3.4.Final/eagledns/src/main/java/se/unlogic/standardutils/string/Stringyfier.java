package se.unlogic.standardutils.string;


public interface Stringyfier {

	public String format(Object bean);
}
