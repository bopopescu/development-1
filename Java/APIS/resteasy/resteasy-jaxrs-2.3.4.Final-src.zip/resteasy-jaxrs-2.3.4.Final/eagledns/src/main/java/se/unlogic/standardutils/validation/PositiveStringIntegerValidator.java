package se.unlogic.standardutils.validation;


public class PositiveStringIntegerValidator extends StringIntegerValidator {

	public PositiveStringIntegerValidator() {

		super(1, null);
	}	
}
