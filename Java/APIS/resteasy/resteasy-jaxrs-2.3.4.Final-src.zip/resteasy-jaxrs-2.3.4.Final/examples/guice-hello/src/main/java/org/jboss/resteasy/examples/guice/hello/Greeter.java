package org.jboss.resteasy.examples.guice.hello;

public interface Greeter
{
   public String greet(final String name);
}
