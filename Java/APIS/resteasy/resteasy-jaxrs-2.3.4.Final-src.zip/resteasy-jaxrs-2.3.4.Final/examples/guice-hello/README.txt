
This project is a simple example showing the guice integration. 

System Requirements:
====================
- Maven 2.0.9 or higher

Building the project:
====================
1. In root directoy

mvn clean install

This will build a WAR and run it with embedded Jetty