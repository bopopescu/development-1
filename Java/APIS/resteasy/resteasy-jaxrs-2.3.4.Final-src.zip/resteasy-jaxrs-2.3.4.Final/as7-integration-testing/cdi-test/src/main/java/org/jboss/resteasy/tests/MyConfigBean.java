package org.jboss.resteasy.tests;

/**
 * @author <a href="mailto:bill@burkecentral.com">Bill Burke</a>
 * @version $Revision: 1 $
 */
public class MyConfigBean
{
   public String version()
   {
      return "1.1";
   }
}
