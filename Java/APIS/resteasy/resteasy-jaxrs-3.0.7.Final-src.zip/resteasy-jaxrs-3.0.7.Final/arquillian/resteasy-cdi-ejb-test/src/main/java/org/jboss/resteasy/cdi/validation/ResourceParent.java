package org.jboss.resteasy.cdi.validation;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Jan 3, 2013
 */
public interface ResourceParent
{
   public abstract int getNumberOne();

   public abstract int getNumberTwo();
}
