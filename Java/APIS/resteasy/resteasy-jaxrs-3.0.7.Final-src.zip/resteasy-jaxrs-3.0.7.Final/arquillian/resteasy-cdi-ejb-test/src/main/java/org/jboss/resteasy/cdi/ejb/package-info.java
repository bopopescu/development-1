/**
 * This package (along with @see org.jboss.resteasy.test.cdi.ejb) tests EJBs used as
 * JAX-RS components.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.ejb;
