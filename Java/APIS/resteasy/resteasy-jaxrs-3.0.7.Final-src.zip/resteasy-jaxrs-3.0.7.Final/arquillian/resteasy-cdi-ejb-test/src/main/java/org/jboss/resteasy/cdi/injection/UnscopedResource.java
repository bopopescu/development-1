package org.jboss.resteasy.cdi.injection;

import javax.ws.rs.Path;

/**
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright May 22, 2012
 */
@Path("/unscoped")
public class UnscopedResource
{

}

