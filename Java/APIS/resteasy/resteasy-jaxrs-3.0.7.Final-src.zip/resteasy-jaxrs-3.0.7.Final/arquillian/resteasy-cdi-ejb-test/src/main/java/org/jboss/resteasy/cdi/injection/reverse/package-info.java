/**
 * This package (along with @see org.jboss.resteasy.test.cdi.injection.reverse) tests injection
 * of JAX-RS components into EJBs.
 * 
 * @see org.jboss.resteasy.package-info.java
 */
package org.jboss.resteasy.cdi.injection.reverse;
