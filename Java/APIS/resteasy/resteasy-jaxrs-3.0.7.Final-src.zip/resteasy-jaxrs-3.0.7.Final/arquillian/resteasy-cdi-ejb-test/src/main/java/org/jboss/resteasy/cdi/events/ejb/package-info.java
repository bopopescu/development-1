/**
 * This package (along with @see org.jboss.resteasy.test.cdi.events.ejb) tests CDI events
 * with EJBs.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.events.ejb;
