package org.jboss.resteasy.cdi.modules;

import javax.ejb.Local;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Dec 20, 2012
 */
@Local
public interface InjectableIntf
{

}