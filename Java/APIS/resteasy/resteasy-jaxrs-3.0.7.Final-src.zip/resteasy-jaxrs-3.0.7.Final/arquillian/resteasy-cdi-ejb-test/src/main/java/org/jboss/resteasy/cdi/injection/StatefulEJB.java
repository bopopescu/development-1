
package org.jboss.resteasy.cdi.injection;

import javax.ejb.Stateful;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright May 24, 2012
 */
@Stateful
public class StatefulEJB
{
}

