package org.jboss.resteasy.cdi.ejb;

import javax.ejb.Remote;

/**
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Jun 29, 2012
 */
@Remote
public interface EJBRemoteResource extends EJBResourceParent
{
}

