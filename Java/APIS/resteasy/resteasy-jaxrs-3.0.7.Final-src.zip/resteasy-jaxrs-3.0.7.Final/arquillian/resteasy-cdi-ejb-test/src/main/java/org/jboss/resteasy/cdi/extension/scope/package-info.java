/**
 * This package (along with @see org.jboss.resteasy.test.cdi.extension.scope) introduces an
 * application defined scope.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.extension.scope;
