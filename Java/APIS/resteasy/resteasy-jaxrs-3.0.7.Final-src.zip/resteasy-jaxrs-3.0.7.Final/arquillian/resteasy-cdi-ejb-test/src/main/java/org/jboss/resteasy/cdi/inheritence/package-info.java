/**
 * This package (along with @see org.jboss.resteasy.test.cdi.inheritence) tests alternatives,
 * alternative stereotypes, and specialization.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.inheritence;
