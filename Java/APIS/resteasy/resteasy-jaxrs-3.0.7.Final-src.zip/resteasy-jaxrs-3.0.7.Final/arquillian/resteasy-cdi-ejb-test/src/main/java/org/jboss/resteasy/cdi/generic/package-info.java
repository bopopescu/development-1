/**
 * This package (along with @see org.jboss.resteasy.test.cdi.generic) tests injection
 * with parameterized required types and/or parameterized bean types.
 * 
 * @see org.jboss.resteasy.package-info.java
 */
package org.jboss.resteasy.cdi.generic;
