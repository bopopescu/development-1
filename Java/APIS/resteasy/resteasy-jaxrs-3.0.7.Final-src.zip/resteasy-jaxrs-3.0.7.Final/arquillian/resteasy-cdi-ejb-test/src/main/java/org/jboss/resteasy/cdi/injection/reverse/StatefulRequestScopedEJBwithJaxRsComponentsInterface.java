package org.jboss.resteasy.cdi.injection.reverse;

import javax.ejb.Local;

/**
 *
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright May 30, 2012
 */
@Local
public interface StatefulRequestScopedEJBwithJaxRsComponentsInterface extends EJBInterface
{
}

