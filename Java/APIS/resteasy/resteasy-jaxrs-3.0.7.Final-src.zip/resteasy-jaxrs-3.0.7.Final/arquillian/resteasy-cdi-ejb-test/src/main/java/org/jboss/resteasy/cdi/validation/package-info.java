/**
 * This package (along with @see org.jboss.resteasy.test.cdi.validation) tests the application
 * of validation (@see JSR 303: Bean Validation) to JAX-RS resources.
 * 
 * @see org.jboss.resteasy.package-info.java
 */
package org.jboss.resteasy.cdi.validation;
